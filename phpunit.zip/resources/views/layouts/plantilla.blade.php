@include('layouts.app') {{-- Meta - NAV - CONTENIDO --}}


{{-- <div class="content-wrapper">
@yield('content')

</div><!-- /.content-wrapper --> --}}


@include('template.footer')
@yield('script')
