<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<P>NOMBRE:<STRONG>{{ $request['name'] }}</STRONG></P>
	<P>EMAIL:<STRONG>{{  $request['email']  }}</STRONG></P>
	<P>MENSAJE:<STRONG>{{  $request['message']  }}</STRONG></P>

</body>
</html>