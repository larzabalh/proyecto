

@section('content')


{{$lstData->id}}


@endsection
