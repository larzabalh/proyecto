<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Facturador extends Model
{
  protected $table = 'facturadores';
  protected $guarded = [];
}
