<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class View_Conceptos extends Model
{
    protected $table = 'view_conceptos';
}
