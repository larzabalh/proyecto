<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Liquidador extends Model
{
  protected $table = 'liquidadores';
  protected $guarded = [];
}
